package TSM;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class Map extends JFrame implements ActionListener {
    Image img=Toolkit.getDefaultToolkit().getImage("F:\\my photoshops\\HRGY6605.JPEG");
    Image img1=Toolkit.getDefaultToolkit().getImage("F:\\my photoshops\\background1.jpg");

    Dice dice;
    JButton backA;
    JButton exitA;
    JButton rollB;
    private Random rand = new Random();
    Map() {
        dice = new Dice();
        rollB = new JButton("Roll");
        Icon backIcon1 = new ImageIcon("F:\\my photoshops\\KZAS6623.jpg");
        Icon exitIcon1 = new ImageIcon("F:\\my photoshops\\KZAS66222.jpg");
        int res = Math.abs(rand.nextInt() % 8);
        backA = new JButton(backIcon1);//back to menu
        exitA=new JButton(exitIcon1);
        this.setContentPane(new JPanel(){

            @Override
            public void paintComponent (Graphics g){
                int[][] map = {
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0},
                        {0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0},
                        {0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0},
                        {0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0},
                        {0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0},
                        {0, 1, 1, 1, 1, 6, 1, 1, 1, 1, 1, 0},
                        {0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0},
                        {0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0},
                        {0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0},
                        {8, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                };
                int x;
                int y;
                for (int i = 0; i < 1; i++) {
                    x = Math.abs((rand.nextInt() % 5)) + 1;
                    y = Math.abs((rand.nextInt() % 2)) + 9;
                    if (map[x][y] == 1) {
                        map[x][y] = 500; //treasure
                    } else i--;
                }
                for (int i = 0; i < 1; i++) {
                    x = Math.abs((rand.nextInt() % 5)) + 1;
                    y = Math.abs((rand.nextInt() % 2)) + 7;
                    if (map[x][y] == 1) {
                        map[x][y] = 600; //treasure
                    } else i--;
                }
                for (int i = 0; i < 1; i++) {
                    x = Math.abs((rand.nextInt() % 5)) + 1;
                    y = Math.abs((rand.nextInt() % 3)) + 1;
                    if (map[x][y] == 1) {
                        map[x][y] = 700; //treasure
                    } else i--;
                }
                for (int i = 0; i < 1; i++) {
                    x = Math.abs((rand.nextInt() % 5)) + 1;
                    y = Math.abs((rand.nextInt() % 3)) + 4;
                    if (map[x][y] == 1) {
                        map[x][y] = 800; //treasure
                    } else i--;
                }
                for (int i = 0; i < 1; i++) {
                    x = Math.abs((rand.nextInt() % 5)) + 6;
                    y = Math.abs((rand.nextInt() % 3)) + 8;
                    if (map[x][y] == 1) {
                        map[x][y] = 400; //treasure
                    } else i--;
                }
                for (int i = 0; i < 1; i++) {
                    x = Math.abs((rand.nextInt() % 5)) + 6;
                    y = Math.abs((rand.nextInt() % 3)) + 5;
                    if (map[x][y] == 1) {
                        map[x][y] = 300; //treasure
                    } else i--;
                }
                for (int i = 0; i < 1; i++) {
                    x = Math.abs((rand.nextInt() % 5)) + 6;
                    y = Math.abs((rand.nextInt() % 2)) + 1;
                    if (map[x][y] == 1) {
                        map[x][y] = 200; //treasure
                    } else i--;
                }
                for (int i = 0; i < 1; i++) {
                    x = Math.abs((rand.nextInt() % 5)) + 6;
                    y = Math.abs((rand.nextInt() % 2)) + 3;
                    if (map[x][y] == 1) {
                        map[x][y] = 100; //treasure
                    } else i--;
                }
                for (int i = 0; i < 13; i++) {
                    x = Math.abs(rand.nextInt() % 10) + 1;
                    y = Math.abs((rand.nextInt() % 10)) + 1;
                    if (map[x][y] == 1) {
                        map[x][y] = 3; //lost Precious
                    } else i--;
                }
                for (int i = 0; i < 5; i++) {
                    x = Math.abs((rand.nextInt() % 10)) + 1;
                    y = Math.abs((rand.nextInt() % 10)) + 1;
                    if (map[x][y] == 1) {
                        map[x][y] = 7; //wall
                    }
                }
                for (int i = 0; i < 5; i++) {
                    x = Math.abs(rand.nextInt() % 10) + 1;
                    y = Math.abs(rand.nextInt() % 10) + 1;
                    if (map[x][y] == 1) {
                        map[x][y] = 4; //market
                    } else i--;
                }
                int j = Math.abs(rand.nextInt() % 5) + 2;
                for (int i = 0; i < j; i++) {
                    x = Math.abs(rand.nextInt() % 10) + 1;
                    y = Math.abs(rand.nextInt() % 10) + 1;
                    if (map[x][y] == 1) {
                        map[x][y] = 5; //trap
                    } else i--;
                    super.paintComponents(g);
                    g.drawImage(img, -1000, -1200, null);
                    g.drawImage(img1, 1290, 0, 650, 1050, null);
                    for (i = 0; i < 12; i++) {
                        for (j = 0; j < 12; j++) {
                            if (map[i][j] == 1) {
                                Image img = Toolkit.getDefaultToolkit().getImage("F:\\my photoshops\\earqe870i1cz13.jpg");
                                g.drawImage(img, i * 75 + 250, j * 75 + 150, null);
                            }
                            if (map[i][j] == 100) {
                                Image img7 = Toolkit.getDefaultToolkit().getImage("F:\\my photoshops\\IMG16.PNG");
                                g.drawImage(img7, i * 75 + 250, j * 75 + 150, 75, 75, null);
                            }
                            if (map[i][j] == 200) {
                                Image img7 = Toolkit.getDefaultToolkit().getImage("F:\\my photoshops\\IMG14.PNG");
                                g.drawImage(img7, i * 75 + 250, j * 75 + 150, 75, 75, null);
                            }
                            if (map[i][j] == 300) {
                                Image img7 = Toolkit.getDefaultToolkit().getImage("F:\\my photoshops\\IMG11.PNG");
                                g.drawImage(img7, i * 75 + 250, j * 75 + 150, 75, 75, null);
                            }
                            if (map[i][j] == 400) {
                                Image img7 = Toolkit.getDefaultToolkit().getImage("F:\\my photoshops\\IMG10.PNG");
                                g.drawImage(img7, i * 75 + 250, j * 75 + 150, 75, 75, null);
                            }
                            if (map[i][j] == 500) {
                                Image img7 = Toolkit.getDefaultToolkit().getImage("F:\\my photoshops\\IMG13.PNG");
                                g.drawImage(img7, i * 75 + 250, j * 75 + 150, 75, 75, null);
                            }
                            if (map[i][j] == 600) {
                                Image img7 = Toolkit.getDefaultToolkit().getImage("F:\\my photoshops\\IMG12.PNG");
                                g.drawImage(img7, i * 75 + 250, j * 75 + 150, 75, 75, null);
                            }
                            if (map[i][j] == 700) {
                                Image img7 = Toolkit.getDefaultToolkit().getImage("F:\\my photoshops\\IMG17.PNG");
                                g.drawImage(img7, i * 75 + 250, j * 75 + 150, 75, 75, null);
                            }
                            if (map[i][j] == 800) {
                                Image img7 = Toolkit.getDefaultToolkit().getImage("F:\\my photoshops\\IMG15.PNG");
                                g.drawImage(img7, i * 75 + 250, j * 75 + 150, 75, 75, null);
                            }
                            if (map[i][j] == 3) {
                                Image img = Toolkit.getDefaultToolkit().getImage("F:\\my photoshops\\UNIY1187.JPEG");
                                g.drawImage(img, i * 75 + 247, j * 75 + 150, null);
                            }
                            if (map[i][j] == 4) {
                                Image img = Toolkit.getDefaultToolkit().getImage("F:\\my photoshops\\earqe870i1cz14.jpg");
                                g.drawImage(img, i * 75 + 250, j * 75 + 150, null);
                            }
                            if (map[i][j] == 5) {
                                Image img = Toolkit.getDefaultToolkit().getImage("F:\\my photoshops\\BMXL64252.jpg");
                                g.drawImage(img, i * 75 + 250, j * 75 + 150, null);
                            }
                            if (map[i][j] == 6) {
                                Image img = Toolkit.getDefaultToolkit().getImage("F:\\my photoshops\\ba4cf8fadc36757ac213b3b5803164551.png");
                                g.drawImage(img, i * 75 + 247, j * 75 + 150, null);
                            }
                            if (map[i][j] == 7) {
                                Image img = Toolkit.getDefaultToolkit().getImage("F:\\my photoshops\\earqe870i1cz12.jpg");
                                g.drawImage(img, i * 75 + 250, j * 75 + 150, null);
                            }
                            if (map[i][j] == 8) {
                                Image img = Toolkit.getDefaultToolkit().getImage("F:\\my photoshops\\ba4cf8fadc36757ac213b3b58031645513.png");
                                g.drawImage(img, 220, 890, null);
                            }
                        }
                    }
                    if (res == 0) {
                        Image img2 = Toolkit.getDefaultToolkit().getImage("F:\\my photoshops\\IMG2.jpg");
                        g.drawImage(img2, 1700, 50, 180, 270, null);
                    }
                    if (res == 1) {
                        Image img2 = Toolkit.getDefaultToolkit().getImage("F:\\my photoshops\\IMG8.jpg");
                        g.drawImage(img2, 1700, 50, 180, 270, null);
                    }
                    if (res == 2) {
                        Image img2 = Toolkit.getDefaultToolkit().getImage("F:\\my photoshops\\IMG7.jpg");
                        g.drawImage(img2, 1700, 50, 180, 270, null);
                    }
                    if (res == 3) {
                        Image img2 = Toolkit.getDefaultToolkit().getImage("F:\\my photoshops\\IMG4.jpg");
                        g.drawImage(img2, 1700, 50, 180, 270, null);
                    }
                    if (res == 4) {
                        Image img2 = Toolkit.getDefaultToolkit().getImage("F:\\my photoshops\\IMG1.jpg");
                        g.drawImage(img2, 1700, 50, 180, 270, null);
                    }
                    if (res == 5) {
                        Image img2 = Toolkit.getDefaultToolkit().getImage("F:\\my photoshops\\IMG6.jpg");
                        g.drawImage(img2, 1700, 50, 180, 270, null);
                    }
                    if (res == 6) {
                        Image img2 = Toolkit.getDefaultToolkit().getImage("F:\\my photoshops\\IMG3.jpg");
                        g.drawImage(img2, 1700, 50, 180, 270, null);
                    }
                    if (res == 7) {
                        Image img2 = Toolkit.getDefaultToolkit().getImage("F:\\my photoshops\\IMG5.jpg");
                        g.drawImage(img2, 1700, 50, 180, 270, null);
                    }
                    Image img3 = Toolkit.getDefaultToolkit().getImage("F:\\my photoshops\\IMG_1962.PNG");
                    g.drawImage(img3, 1740, 420, 130, 130, null);
                    Image img4 = Toolkit.getDefaultToolkit().getImage("F:\\my photoshops\\IMG_1961.PNG");
                    g.drawImage(img4, 1740, 680, 130, 130, null);
                    Image img5 = Toolkit.getDefaultToolkit().getImage("F:\\my photoshops\\JZHO9321.PNG");
                    g.drawImage(img5, 220, 855, 30, 95, null);
                    Image img6 = Toolkit.getDefaultToolkit().getImage("F:\\my photoshops\\TUGR3735.PNG");
                    g.drawImage(img6, 255, 850, 28, 100, null);
                }
                if (SetChar.ans==1){
                    TextArea textArea=new TextArea(SetChar.player2name);
                    textArea.setBounds( 1740, 420, 130, 130);
                    add(textArea);
                    TextArea textArea2=new TextArea("Player2");
                    textArea2.setBounds( 1740, 420, 130, 130);
                    add(textArea2);
                    TextArea textArea1=new TextArea(SetChar.player1name);
                    textArea1.setBounds( 1740, 680, 130, 130);
                    add(textArea1);
                    TextArea textArea3=new TextArea("Player1");
                    textArea3.setBounds( 1740, 680, 130, 130);
                    add(textArea3);
                }
                if(SetChar.ans==1){
                    TextArea textArea=new TextArea(SetChar.player1name);
                    textArea.setBounds( 1740, 420, 130, 130);
                    add(textArea);
                    TextArea textArea2=new TextArea("Player1");
                    textArea2.setBounds( 1740, 420, 130, 130);
                    add(textArea2);
                    TextArea textArea1=new TextArea(SetChar.player2name);
                    textArea1.setBounds( 1740, 680, 130, 130);
                    add(textArea1);
                    TextArea textArea3=new TextArea("Player2");
                    textArea3.setBounds( 1740, 680, 130, 130);
                    add(textArea3);
                }
                backA.setBounds(1550, 830, 395, 80);
                exitA.setBounds(1550, 920, 395, 80);
                dice.setBounds(30,20,80,80);
                rollB.setBounds(30,80,60,60);
            }
        });

        this.add(dice);
        this.add(rollB);
        pack();
        setVisible(true);
        this.add(backA);
        this.add(exitA);


        exitA.addActionListener(this);
        backA.addActionListener(this);

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setTitle("Travelling Sales Man ");
        this.setBounds(600, 200, 300, 120);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        ImageIcon img1=new ImageIcon("F:\\my photoshops\\EZMW0610.JPEG");
        this.setIconImage(img1.getImage());
        rollB.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dice.roll();
            }
        });
    }
    @Override
    public void actionPerformed(ActionEvent e){
        if (e.getSource() == backA) {
            int ans = JOptionPane.showConfirmDialog(null, "Leave game and Back to menu?", "Attention", JOptionPane.YES_NO_CANCEL_OPTION);
            if (ans == 0) {
                this.setVisible(false);
                new Menu();
            }
            if (ans==1){
                this.setVisible(true);
            }
            if (ans==-1){
                this.setVisible(true);
            }
        }
        if (e.getSource() == exitA) {
            int ans = JOptionPane.showConfirmDialog(null, "Are you sure you want to exit?", "Attention", JOptionPane.YES_NO_CANCEL_OPTION);
            if (ans == 0) {
                this.setVisible(false);
            }
            if (ans==1){
                this.setVisible(true);
            }
            if (ans==-1){
                this.setVisible(true);
            }
        }
    }
}

