package TSM;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class Map extends JFrame implements ActionListener{
    Image img=Toolkit.getDefaultToolkit().getImage("F:\\TMS-H\\res\\HRGY6605.JPEG");
    Image img1=Toolkit.getDefaultToolkit().getImage("F:\\TMS-H\\res\\background1.jpg");
    Dice dice;
    Map(){
        Random rand=new Random();
        int res=Math.abs(rand.nextInt()%8);
        dice = new Dice();
        this.setContentPane(new JPanel(){
            @Override
            public void paintComponent(Graphics g){
                int [][] map={
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 1, 1, 1, 1, 1, 1, 1 ,1, 1, 1, 0},
                        {0, 1, 1, 1, 1, 1, 1, 1 ,1, 1, 1, 0},
                        {0, 1, 1, 1, 1, 1, 1, 1 ,1, 1, 1, 0},
                        {0, 1, 1, 1, 1, 1, 1, 1 ,1, 1, 1, 0},
                        {0, 1, 1, 1, 1, 1, 1, 1 ,1, 1, 1, 0},
                        {0, 1, 1, 1, 1, 6, 1, 1 ,1, 1, 1, 0},
                        {0, 1, 1, 1, 1, 1, 1, 1 ,1, 1, 1, 0},
                        {0, 1, 1, 1, 1, 1, 1, 1 ,1, 1, 1, 0},
                        {0, 1, 1, 1, 1, 1, 1, 1 ,1, 1, 1, 0},
                        {8, 1, 1, 1, 1, 1, 1, 1 ,1, 1, 1, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                };
                dice.setBounds(100,100,100,100);
                this.add(dice);
                JButton rollB = new JButton("Roll");
                rollB.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        dice.roll();
                    }
                });
                rollB.setBounds(200,200,50,50);
                this.add(rollB);
                int x;
                int y;
                for (int i = 0; i < 1; i++) {
                    x = Math.abs((rand.nextInt() % 5))+1;
                    y = Math.abs((rand.nextInt() % 2))+10;
                    if (map[x][y] == 1) {
                        map[x][y] = 2; //treasure
                    }
                    else i--;
                }
                for (int i = 0; i < 1; i++) {
                    x = Math.abs((rand.nextInt() % 5))+1;
                    y = Math.abs((rand.nextInt() % 3))+7;
                    if (map[x][y] == 1) {
                        map[x][y] = 2; //treasure
                    }
                    else i--;
                }
                for (int i = 0; i < 1; i++) {
                    x = Math.abs((rand.nextInt() % 5))+1;
                    y = Math.abs((rand.nextInt() % 3))+1;
                    if (map[x][y] == 1) {
                        map[x][y] = 2; //treasure
                    }
                    else i--;
                }
                for (int i = 0; i < 1; i++) {
                    x = Math.abs((rand.nextInt() % 5))+1;
                    y = Math.abs((rand.nextInt() % 3))+4;
                    if (map[x][y] == 1) {
                        map[x][y] = 2; //treasure
                    }
                    else i--;
                }
                for (int i = 0; i < 1; i++) {
                    x = Math.abs((rand.nextInt() % 5))+6;
                    y = Math.abs((rand.nextInt() % 2))+10;
                    if (map[x][y] == 1) {
                        map[x][y] = 2; //treasure
                    }
                    else i--;
                }
                for (int i = 0; i < 1; i++) {
                    x = Math.abs((rand.nextInt() % 5))+6;
                    y = Math.abs((rand.nextInt() % 3))+7;
                    if (map[x][y] == 1) {
                        map[x][y] = 2; //treasure
                    }
                    else i--;
                }
                for (int i = 0; i < 1; i++) {
                    x = Math.abs((rand.nextInt() % 5))+6;
                    y = Math.abs((rand.nextInt() % 3))+1;
                    if (map[x][y] == 1) {
                        map[x][y] = 2; //treasure
                    }
                    else i--;
                }
                for (int i = 0; i < 1; i++) {
                    x = Math.abs((rand.nextInt() % 5))+6;
                    y = Math.abs((rand.nextInt() % 3))+4;
                    if (map[x][y] == 1) {
                        map[x][y] = 2; //treasure
                    }
                    else i--;
                }
                for (int i = 0; i <13; i++) {
                    x = Math.abs(rand.nextInt() % 10)+ 1;
                    y = Math.abs((rand.nextInt() % 10))+ 1;
                    if (map[x][y] == 1) {
                        map[x][y] = 3; //lost Precious
                    }
                    else i--;
                }
                for (int i = 0; i < 5; i++) {
                    x = Math.abs((rand.nextInt() % 10))+ 1;
                    y = Math.abs((rand.nextInt() % 10))+ 1;
                    if (map[x][y] == 1) {
                        map[x][y] = 7; //wall
                    }
                }
                for (int i = 0; i < 5; i++) {
                    x = Math.abs(rand.nextInt() % 10) + 1;
                    y = Math.abs(rand.nextInt() % 10) + 1;
                    if (map[x][y] == 1) {
                        map[x][y] = 4; //market
                    }
                    else i--;
                }
                int j = Math.abs(rand.nextInt() % 5) + 2;
                for (int i = 0; i < j; i++) {
                    x = Math.abs(rand.nextInt() % 10) + 1;
                    y = Math.abs(rand.nextInt() % 10) + 1;
                    if (map[x][y] == 1) {
                        map[x][y] = 5; //trap
                    }
                    else i--;
                }
                super.paintComponents(g);
                g.drawImage(img, -1000, -1200, null);
                g.drawImage(img1, 1290, 0, null);
                int i;
                for(i=0 ; i<12 ; i++){
                    for (j=0 ; j<12 ; j++) {
                        if (map[i][j] == 1) {
                            Image img=Toolkit.getDefaultToolkit().getImage("F:\\TMS-H\\res\\earqe870i1cz13.jpg");
                            g.drawImage(img, i*75+250, j*75+150, null);
                        }
                        if (map[i][j] == 2) {
                            Image img=Toolkit.getDefaultToolkit().getImage("F:\\TMS-H\\res\\IBPX3526.JPEG");
                            g.drawImage(img, i*75+250, j*75+150, null);
                        }
                        if (map[i][j] == 3) {
                            Image img=Toolkit.getDefaultToolkit().getImage("F:\\TMS-H\\res\\UNIY1187.JPEG");
                            g.drawImage(img, i*75+247, j*75+150, null);
                        }
                        if (map[i][j] == 4) {
                            Image img=Toolkit.getDefaultToolkit().getImage("F:\\TMS-H\\res\\earqe870i1cz14.jpg");
                            g.drawImage(img, i*75+250, j*75+150, null);
                        }
                        if (map[i][j] == 5) {
                            Image img=Toolkit.getDefaultToolkit().getImage("F:\\TMS-H\\res\\BMXL64252.jpg");
                            g.drawImage(img, i*75+250, j*75+150, null);
                        }
                        if (map[i][j] == 6) {
                            Image img=Toolkit.getDefaultToolkit().getImage("F:\\TMS-H\\res\\ba4cf8fadc36757ac213b3b5803164551.png");
                            g.drawImage(img, i*75+247, j*75+150, null);
                        }
                        if (map[i][j] == 7) {
                            Image img=Toolkit.getDefaultToolkit().getImage("F:\\TMS-H\\res\\earqe870i1cz12.jpg");
                            g.drawImage(img, i*75+250, j*75+150, null);
                        }
                        if(map[i][j]==8){
                            Image img=Toolkit.getDefaultToolkit().getImage("F:\\TMS-H\\res\\ba4cf8fadc36757ac213b3b58031645513.png");
                            g.drawImage(img, 220, 890, null);
                        }
                    }
                }
                if(res==0){
                    Image img2=Toolkit.getDefaultToolkit().getImage("F:\\TMS-H\\res\\IMG2.jpg");
                    g.drawImage(img2, 1730, 50, 180, 270,null);
                }
                if(res==1){
                    Image img2=Toolkit.getDefaultToolkit().getImage("F:\\TMS-H\\res\\IMG8.jpg");
                    g.drawImage(img2, 1730, 50, 180, 270,null);
                }
                if(res==2){
                    Image img2=Toolkit.getDefaultToolkit().getImage("F:\\TMS-H\\res\\IMG7.jpg");
                    g.drawImage(img2, 1730, 50, 180, 270,null);
                }
                if(res==3){
                    Image img2=Toolkit.getDefaultToolkit().getImage("F:\\TMS-H\\res\\IMG4.jpg");
                    g.drawImage(img2, 1730, 50, 180, 270,null);
                }
                if(res==4){
                    Image img2=Toolkit.getDefaultToolkit().getImage("F:\\TMS-H\\res\\IMG1.jpg");
                    g.drawImage(img2, 1730, 50, 180, 270,null);
                }
                if(res==5){
                    Image img2=Toolkit.getDefaultToolkit().getImage("F:\\TMS-H\\res\\IMG6.jpg");
                    g.drawImage(img2, 1730, 50, 180, 270,null);
                }
                if(res==6){
                    Image img2=Toolkit.getDefaultToolkit().getImage("F:\\TMS-H\\res\\IMG3.jpg");
                    g.drawImage(img2, 1730, 50, 180, 270,null);
                }
                if(res==7){
                    Image img2=Toolkit.getDefaultToolkit().getImage("F:\\TMS-H\\res\\IMG5.jpg");
                    g.drawImage(img2, 1730, 50, 180, 270,null);
                }
            }
        });


        pack();
        setVisible(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setTitle("Travelling Sales Man ");
        this.setBounds(600, 200, 300, 120);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        ImageIcon img1=new ImageIcon("F:\\TMS-H\\res\\EZMW0610.JPEG");
        this.setIconImage(img1.getImage());
    }

    @Override
    public void actionPerformed(ActionEvent e) {
    }
}
