package TSM;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class Dice extends JPanel {
    private JLabel diceL;
    private Timer timer;
    private int result = 0;
    private int counter=0;
    private boolean rolling = false;
    private Random rand = new Random();

    public Dice(){
        setPreferredSize(new Dimension(200,200));
        setLayout(new BorderLayout());
        diceL = new JLabel(new ImageIcon("F:\\TMS-H\\res\\DIce\\Dice1.png"));
        add(diceL,BorderLayout.CENTER);
        timer = new Timer(100, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                counter++;
                if(counter > 10){
                    rolling = false;
                    result = rand.nextInt(6)+1;
                    diceL.setIcon(new ImageIcon("F:\\TMS-H\\res\\DIce\\Dice"+result+".png"));
                    timer.stop();
                }
                else{
                    int value = rand.nextInt(6)+1;
                    diceL.setIcon(new ImageIcon("F:\\TMS-H\\res\\DIce\\Dice"+value+".png"));
                }
            }
        });
    }
    public void roll(){
        if(!rolling){
            rolling = true;
            counter = 0;
            timer.start();
        }
    }
}
