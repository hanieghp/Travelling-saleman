package TSM;

import javax.swing.*;
import javax.swing.text.html.Option;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SetChar extends JFrame{
    Image image = Toolkit.getDefaultToolkit().getImage("F:\\TMS-H\\res\\Farm.jpg");
    String player1name="player1",player2name="player2";
    String player1choice,player2choice;
    int sw=0;
    SetChar(){
        JTextField name1 = new JTextField();
        JTextField name2 = new JTextField();
        JTextArea text1 = new JTextArea("   PLayer1 name ");
        JTextArea text2 = new JTextArea("   Player2 name ");
        Icon enterI = new ImageIcon("F:\\TMS-H\\res\\enterB.JPEG");
        JButton enter = new JButton(enterI);
        Icon showI = new ImageIcon("F:\\TMS-H\\res\\showB.JPEG");
        JLabel imgP1 = new JLabel(new ImageIcon("F:\\TMS-H\\res\\player1.jpg"));
        JLabel imgP2 = new JLabel(new ImageIcon("F:\\TMS-H\\res\\player2.jpg"));
        JButton show = new JButton(showI);
        this.setContentPane(new JPanel(){
            @Override
            public void paintComponent(Graphics g) {
                g.drawImage(image, 0, 0, null);
                name1.setBounds(90, 200, 100, 50);
                name2.setBounds(90, 350, 100, 50);
                text1.setBounds(90, 170, 100, 30);
                text2.setBounds(90, 320, 100, 30);
                text1.setEnabled(false);
                text2.setEnabled(false);
                this.add(name1);
                this.add(name2);
                this.add(text1);
                this.add(text2);
//                JButton enter = new JButton(enterI);
                enter.setBounds(90, 450, 100, 50);
                this.add(enter);
                player1name = name1.getText();
                player2name = name2.getText();
                this.add(imgP1);
                this.add(imgP2);
                String options[] = {"Scarlett Fox", "Guy Dangerous"};
                final JComboBox choser = new JComboBox(options);
//                JLabel nameshow1 = new JLabel(player1name);
//                JLabel nameshow2 = new JLabel(player2name);
                this.add(choser);
                this.add(show);
                if(player1name == null){
                    player1name="player1";
                }
                if(player2name == null){
                    player2name="player2";
                }
                JLabel nameshow1 = new JLabel(player1name);
                JLabel nameshow2 = new JLabel(player2name);
                this.add(nameshow1);
                this.add(nameshow2);
                Icon backIcon = new ImageIcon("F:\\TMS-H\\res\\BackB-set.JPEG");
                Icon startIcon = new ImageIcon("F:\\TMS-H\\res\\StartB-set.JPEG");
                JButton start = new JButton(startIcon);
                JButton back = new JButton(backIcon);
                back.setBounds(15,650,90,40);
                this.add(back);
                this.add(start);
                enter.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        imgP1.setBounds(400, 100, 300, 500);
                        imgP2.setBounds(750, 100, 300, 500);
                        imgP1.setVisible(true);imgP2.setVisible(true);
                        choser.setBounds(1200, 100, 150, 120);
                        show.setBounds(1225, 270, 100, 50);
                        sw = 1;
                    }
                });
                if(sw == 1){
                    show.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            player1choice = (String) choser.getItemAt(choser.getSelectedIndex());
                            if(player1choice.equals("Scarlett Fox")){
                                nameshow1.setBounds(500,20,100,150);
                                nameshow2.setBounds(850,20,100,150);
                            }
                            else{
                                nameshow2.setBounds(500,20,100,150);
                                nameshow1.setBounds(850,20,100,150);
                            }
                            sw = 2;
                        }
                    });
                }
                if(sw == 2){
                    start.setBounds(1180,400,200,100);
                    start.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            JFrame now = (JFrame)
                            SwingUtilities.getWindowAncestor(start);
                            now.dispose();
                            new Map();
                        }
                    });
                }
                back.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        JFrame now = (JFrame)
                        SwingUtilities.getWindowAncestor(start);
                        now.dispose();
                        new Menu();
                    }
                });
            }
        });
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setTitle("custom");
        this.setBounds(0, 0, 300, 120);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        this.setSize(400, 500);
        this.setLayout(null);
        this.setVisible(true);
        this.setSize(600, 600);
        ImageIcon img1=new ImageIcon("F:\\TMS-H\\res\\EZMW0610.JPEG");
        this.setIconImage(img1.getImage());
    }
}
