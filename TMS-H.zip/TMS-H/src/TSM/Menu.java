package TSM;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Menu extends JFrame{
    Image img1=Toolkit.getDefaultToolkit().getImage("F:\\TMS-H\\res\\UPUA66131.JPEG");

    Menu(){
        Icon startIcon = new ImageIcon("F:\\TMS-H\\res\\StartB.JPEG");
        Icon exitIcon = new ImageIcon("F:\\TMS-H\\res\\ExitB.JPEG");
        Icon aboutIcon = new ImageIcon("F:\\TMS-H\\res\\aboutB.JPEG");
        JButton startB = new JButton(startIcon);
        this.setContentPane(new JPanel() {
            @Override
            public void paintComponent(Graphics g) {
                g.drawImage(img1, -960, -1250, null);
                JButton startB = new JButton(startIcon);
                startB.setBounds(600,500,300,70);
                this.add(startB);
                startB.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        JFrame nowS = (JFrame)
                        SwingUtilities.getWindowAncestor(startB);
                        nowS.dispose();
                        new SetChar();

                    }
                });
                JButton aboutB = new JButton(aboutIcon);//About
                aboutB.setBounds(1320,715,200,30);
                this.add(aboutB);
                aboutB.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        JFrame now = (JFrame)
                        SwingUtilities.getWindowAncestor(aboutB);
                        now.dispose();
                        new About();
                    }
                });
            }
        });
        pack();
        setVisible(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setTitle("Menu");
        this.setBounds(0, 0, 300, 120);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        this.setSize(400, 500);
        this.setLayout(null);
        this.setVisible(true);
        this.setSize(600, 600);
        JButton exitB = new JButton(exitIcon);//Exit
        exitB.addActionListener(e -> this.setVisible(false));
        exitB.setBounds(1320, 760, 200, 30);
        add(exitB);
        ImageIcon img1=new ImageIcon("F:\\TMS-H\\res\\EZMW0610.JPEG");
        this.setIconImage(img1.getImage());
        //new Map();
    }
}